(function () {
  const form = document.getElementById('search-form');
  const countryInput = document.getElementById('country');
  const keywordInput = document.getElementById('keyword');
  const grid = document.getElementById('product-grid');
  const resultCount = document.getElementById('result-count');
  const loading = document.getElementById('loading');
  const emptyState = document.getElementById('empty-state');

  function setLoading(isLoading) {
    loading.classList.toggle('hidden', !isLoading);
    grid.classList.toggle('hidden', isLoading);
    emptyState.classList.add('hidden');
    if (isLoading) resultCount.textContent = 'Searching...';
  }

  function adStatus(count) {
    if (count >= 100) return { label: 'Hot', cls: 'bg-rose-50 text-rose-700 ring-rose-600/20' };
    if (count >= 50) return { label: 'Active', cls: 'bg-emerald-50 text-emerald-700 ring-emerald-600/20' };
    return { label: 'Emerging', cls: 'bg-amber-50 text-amber-700 ring-amber-600/20' };
  }

  function formatNumber(n) {
    return new Intl.NumberFormat().format(n);
  }

  function renderCard(product) {
    const status = adStatus(product.active_ad_count);
    return `
      <article class="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden hover:shadow-md transition-shadow">
        <div class="aspect-[4/3] bg-slate-100 overflow-hidden">
          <img src="${product.image_url}" alt="${escapeHtml(product.product_title)}"
               class="h-full w-full object-cover" loading="lazy"
               onerror="this.src='https://placehold.co/400x300?text=No+Image'; this.onerror=null;" />
        </div>
        <div class="p-4">
          <div class="flex items-start justify-between gap-2 mb-2">
            <h3 class="text-sm font-semibold text-slate-900 leading-snug line-clamp-2" title="${escapeHtml(product.product_title)}">${escapeHtml(product.product_title)}</h3>
          </div>
          <div class="flex items-center gap-2 mb-3">
            <span class="inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium ring-1 ring-inset ${status.cls}">${status.label}</span>
            <span class="text-xs text-slate-500">${escapeHtml(product.country)}</span>
          </div>
          <dl class="grid grid-cols-2 gap-3 text-sm">
            <div class="bg-slate-50 rounded-lg p-2.5">
              <dt class="text-xs text-slate-500">Active Ads</dt>
              <dd class="font-semibold text-slate-900">${formatNumber(product.active_ad_count)}</dd>
            </div>
            <div class="bg-slate-50 rounded-lg p-2.5">
              <dt class="text-xs text-slate-500">Est. Daily Sales</dt>
              <dd class="font-semibold text-slate-900">${formatNumber(product.estimated_daily_sales)}</dd>
            </div>
          </dl>
        </div>
      </article>
    `;
  }

  function escapeHtml(str) {
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  async function fetchProducts() {
    const params = new URLSearchParams();
    const keyword = keywordInput.value.trim();
    const country = countryInput.value;
    if (keyword) params.set('keyword', keyword);
    if (country) params.set('country', country);

    setLoading(true);
    try {
      const res = await fetch(`/api/search?${params.toString()}`, {
        headers: { 'Accept': 'application/json' }
      });
      if (!res.ok) throw new Error(`Request failed: ${res.status}`);
      const data = await res.json();
      const results = Array.isArray(data.results) ? data.results : [];

      loading.classList.add('hidden');
      grid.classList.remove('hidden');
      resultCount.textContent = `${results.length} product${results.length === 1 ? '' : 's'} found`;

      if (results.length === 0) {
        grid.innerHTML = '';
        emptyState.classList.remove('hidden');
        return;
      }

      emptyState.classList.add('hidden');
      grid.innerHTML = results.map(renderCard).join('');
    } catch (err) {
      loading.classList.add('hidden');
      grid.classList.remove('hidden');
      emptyState.classList.add('hidden');
      resultCount.textContent = 'Error loading results';
      grid.innerHTML = `
        <div class="col-span-full bg-rose-50 border border-rose-200 text-rose-700 rounded-lg p-4 text-sm">
          Failed to fetch products. ${escapeHtml(err.message || 'Unknown error')}
        </div>`;
      console.error(err);
    }
  }

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    fetchProducts();
  });

  // Initial load
  fetchProducts();
})();
