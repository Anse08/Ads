package com.example.moviestvapp.data.source.registry

import com.example.moviestvapp.data.source.contract.MediaSource
import com.example.moviestvapp.domain.model.SourceInfo
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Central registry for all available [MediaSource] implementations.
 * New sources can be added via Hilt multibindings without changing app logic.
 */
@Singleton
class SourceRegistry @Inject constructor(
    private val sources: Set<@JvmSuppressWildcards MediaSource>
) {
    fun all(): List<MediaSource> = sources.sortedByDescending { it.info.priority }

    fun enabled(): List<MediaSource> = all().filter { it.info.enabled }

    fun getById(id: String): MediaSource? = sources.firstOrNull { it.info.id == id }

    fun infoList(): List<SourceInfo> = all().map { it.info }

    fun movieSources(): List<MediaSource> = enabled().filter { it.info.supportsMovies }

    fun seriesSources(): List<MediaSource> = enabled().filter { it.info.supportsSeries }
}
