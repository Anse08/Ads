package com.example.moviestvapp.presentation.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlaceholderScreen(
    title: String,
    subtitle: String,
    modifier: Modifier = Modifier,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null
) {
    Scaffold(
        topBar = { TopAppBar(title = { Text(title) }) },
        modifier = modifier
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.padding(24.dp)
            ) {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
                if (actionLabel != null && onAction != null) {
                    Button(onClick = onAction) { Text(actionLabel) }
                }
            }
        }
    }
}

@Composable
fun HomeScreen(
    onOpenSearch: () -> Unit,
    onOpenSettings: () -> Unit
) {
    PlaceholderScreen(
        title = "Home",
        subtitle = "Project structure is ready.\nNo real sources are configured yet.\nAdd MediaSource implementations via Hilt multibindings.",
        actionLabel = "Open Search",
        onAction = onOpenSearch
    )
}

@Composable
fun SearchScreen(onBack: () -> Unit) {
    PlaceholderScreen(
        title = "Search",
        subtitle = "Search UI placeholder.\nConnect to SourceRegistry when a source is added.",
        actionLabel = "Back",
        onAction = onBack
    )
}

@Composable
fun MovieDetailScreen(sourceId: String, movieId: String, onBack: () -> Unit) {
    PlaceholderScreen(
        title = "Movie Details",
        subtitle = "Source: $sourceId\nMovie ID: $movieId\nDetails and stream sources will load on demand.",
        actionLabel = "Back",
        onAction = onBack
    )
}

@Composable
fun SeriesDetailScreen(sourceId: String, seriesId: String, onBack: () -> Unit) {
    PlaceholderScreen(
        title = "Series Details",
        subtitle = "Source: $sourceId\nSeries ID: $seriesId\nSeasons and episodes will load on demand.",
        actionLabel = "Back",
        onAction = onBack
    )
}

@Composable
fun PlayerScreen(title: String, onBack: () -> Unit) {
    PlaceholderScreen(
        title = "Player",
        subtitle = "Media3 ExoPlayer will be integrated here.\nSupports HLS/MP4 and quality/subtitle selection.\n\n$title",
        actionLabel = "Back",
        onAction = onBack
    )
}

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    PlaceholderScreen(
        title = "Settings",
        subtitle = "Source management, preferences, and player options will appear here.",
        actionLabel = "Back",
        onAction = onBack
    )
}
