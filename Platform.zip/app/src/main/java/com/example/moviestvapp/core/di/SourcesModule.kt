package com.example.moviestvapp.core.di

import com.example.moviestvapp.data.source.contract.MediaSource
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import dagger.multibindings.Multibinds

/**
 * Binds the set of [MediaSource] implementations.
 * Add new sources by creating a module that contributes an implementation into this set:
 *
 * @Binds @IntoSet abstract fun bindMySource(impl: MySource): MediaSource
 */
@Module
@InstallIn(SingletonComponent::class)
abstract class SourcesModule {
    @Multibinds
    abstract fun bindMediaSources(): Set<MediaSource>
}
