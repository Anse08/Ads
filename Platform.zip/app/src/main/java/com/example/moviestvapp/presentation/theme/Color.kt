package com.example.moviestvapp.presentation.theme

import androidx.compose.ui.graphics.Color

val Primary = Color(0xFF7DD3FC)
val OnPrimary = Color(0xFF003547)
val PrimaryContainer = Color(0xFF004D65)
val OnPrimaryContainer = Color(0xFFC2E8FF)

val Secondary = Color(0xFFB5CAD7)
val OnSecondary = Color(0xFF1F333D)
val SecondaryContainer = Color(0xFF364954)
val OnSecondaryContainer = Color(0xFFD1E5F3)

val Tertiary = Color(0xFFCCC1E9)
val OnTertiary = Color(0xFF332B4B)
val TertiaryContainer = Color(0xFF4A4263)
val OnTertiaryContainer = Color(0xFFE8DDFF)

val Background = Color(0xFF0F1417)
val OnBackground = Color(0xFFDFE3E7)
val Surface = Color(0xFF0F1417)
val OnSurface = Color(0xFFDFE3E7)
val SurfaceVariant = Color(0xFF40484C)
val OnSurfaceVariant = Color(0xFFC0C7CD)
val Outline = Color(0xFF8A9297)
val Error = Color(0xFFFFB4AB)
val OnError = Color(0xFF690005)
