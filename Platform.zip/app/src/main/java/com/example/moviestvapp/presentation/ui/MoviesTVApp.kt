package com.example.moviestvapp.presentation.ui

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.example.moviestvapp.presentation.navigation.Route

@Composable
fun MoviesTVApp() {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = Route.Home
    ) {
        composable<Route.Home> {
            HomeScreen(
                onOpenSearch = { navController.navigate(Route.Search) },
                onOpenSettings = { navController.navigate(Route.Settings) }
            )
        }

        composable<Route.Search> {
            SearchScreen(onBack = { navController.popBackStack() })
        }

        composable<Route.Settings> {
            SettingsScreen(onBack = { navController.popBackStack() })
        }

        composable<Route.MovieDetail> { backStackEntry ->
            val route = backStackEntry.toRoute<Route.MovieDetail>()
            MovieDetailScreen(
                sourceId = route.sourceId,
                movieId = route.movieId,
                onBack = { navController.popBackStack() }
            )
        }

        composable<Route.SeriesDetail> { backStackEntry ->
            val route = backStackEntry.toRoute<Route.SeriesDetail>()
            SeriesDetailScreen(
                sourceId = route.sourceId,
                seriesId = route.seriesId,
                onBack = { navController.popBackStack() }
            )
        }

        composable<Route.Player> { backStackEntry ->
            val route = backStackEntry.toRoute<Route.Player>()
            PlayerScreen(
                title = route.title.ifBlank { "Playback" },
                onBack = { navController.popBackStack() }
            )
        }
    }
}
