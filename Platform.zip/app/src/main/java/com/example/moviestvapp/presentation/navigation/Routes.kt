package com.example.moviestvapp.presentation.navigation

import kotlinx.serialization.Serializable

sealed interface Route {
    @Serializable
    data object Home : Route

    @Serializable
    data object Search : Route

    @Serializable
    data object Settings : Route

    @Serializable
    data class MovieDetail(
        val sourceId: String,
        val movieId: String
    ) : Route

    @Serializable
    data class SeriesDetail(
        val sourceId: String,
        val seriesId: String
    ) : Route

    @Serializable
    data class Player(
        val sourceId: String,
        val mediaId: String,
        val mediaType: String, // "movie" or "series"
        val seasonNumber: Int = -1,
        val episodeNumber: Int = -1,
        val title: String = ""
    ) : Route
}
