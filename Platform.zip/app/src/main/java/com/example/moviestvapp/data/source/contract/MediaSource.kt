package com.example.moviestvapp.data.source.contract

import com.example.moviestvapp.core.common.AppResult
import com.example.moviestvapp.domain.model.Episode
import com.example.moviestvapp.domain.model.MediaItem
import com.example.moviestvapp.domain.model.MovieDetails
import com.example.moviestvapp.domain.model.Season
import com.example.moviestvapp.domain.model.SeriesDetails
import com.example.moviestvapp.domain.model.SourceInfo
import com.example.moviestvapp.domain.model.StreamSource

/**
 * Contract that every media source (scraper/provider) must implement.
 * Implementations should fetch data on-demand and avoid local persistence of media content.
 */
interface MediaSource {
    val info: SourceInfo

    suspend fun search(query: String, page: Int = 1): AppResult<List<MediaItem>>

    suspend fun getTrendingMovies(page: Int = 1): AppResult<List<MediaItem>> =
        AppResult.Success(emptyList())

    suspend fun getTrendingSeries(page: Int = 1): AppResult<List<MediaItem>> =
        AppResult.Success(emptyList())

    suspend fun getMovieDetails(movieId: String): AppResult<MovieDetails>

    suspend fun getSeriesDetails(seriesId: String): AppResult<SeriesDetails>

    suspend fun getSeasons(seriesId: String): AppResult<List<Season>>

    suspend fun getEpisodes(seriesId: String, seasonNumber: Int): AppResult<List<Episode>>

    suspend fun getMovieStreamSources(movieId: String): AppResult<List<StreamSource>>

    suspend fun getEpisodeStreamSources(
        seriesId: String,
        seasonNumber: Int,
        episodeNumber: Int
    ): AppResult<List<StreamSource>>
}
