package com.example.moviestvapp.data.source.base

import com.example.moviestvapp.core.common.AppResult
import com.example.moviestvapp.data.source.contract.MediaSource
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import java.io.IOException

/**
 * Base class for HTTP/HTML-based sources.
 * Provides shared networking and parsing helpers. Concrete sources implement [MediaSource].
 */
abstract class BaseScraper(
    protected val client: OkHttpClient
) : MediaSource {

    protected suspend fun <T> safeCall(block: suspend () -> T): AppResult<T> =
        withContext(Dispatchers.IO) {
            try {
                AppResult.Success(block())
            } catch (ce: CancellationException) {
                throw ce
            } catch (e: Throwable) {
                AppResult.Error(e.message ?: "Source error", e)
            }
        }

    protected fun get(
        url: String,
        headers: Map<String, String> = emptyMap()
    ): Response {
        val builder = Request.Builder().url(url).get()
        headers.forEach { (k, v) -> builder.addHeader(k, v) }
        defaultHeaders().forEach { (k, v) ->
            if (builder.build().header(k) == null) builder.addHeader(k, v)
        }
        return client.newCall(builder.build()).execute()
    }

    protected fun fetchDocument(
        url: String,
        headers: Map<String, String> = emptyMap()
    ): Document {
        get(url, headers).use { response ->
            if (!response.isSuccessful) {
                throw IOException("HTTP ${response.code} for $url")
            }
            val body = response.body?.string().orEmpty()
            return Jsoup.parse(body, url)
        }
    }

    protected fun fetchString(
        url: String,
        headers: Map<String, String> = emptyMap()
    ): String {
        get(url, headers).use { response ->
            if (!response.isSuccessful) {
                throw IOException("HTTP ${response.code} for $url")
            }
            return response.body?.string().orEmpty()
        }
    }

    protected open fun defaultHeaders(): Map<String, String> = mapOf(
        "User-Agent" to DEFAULT_USER_AGENT,
        "Accept" to "text/html,application/json;q=0.9,*/*;q=0.8"
    )

    companion object {
        const val DEFAULT_USER_AGENT =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    }
}
