package com.example.moviestvapp.domain.model

import kotlinx.serialization.Serializable

enum class MediaType {
    MOVIE,
    SERIES
}

@Serializable
data class SourceInfo(
    val id: String,
    val name: String,
    val baseUrl: String,
    val supportsMovies: Boolean = true,
    val supportsSeries: Boolean = true,
    val priority: Int = 0,
    val enabled: Boolean = true
)

@Serializable
data class MediaItem(
    val id: String,
    val sourceId: String,
    val title: String,
    val posterUrl: String? = null,
    val backdropUrl: String? = null,
    val overview: String? = null,
    val year: Int? = null,
    val rating: Double? = null,
    val mediaType: MediaType,
    val genres: List<String> = emptyList()
)

@Serializable
data class MovieDetails(
    val item: MediaItem,
    val runtimeMinutes: Int? = null,
    val tagline: String? = null,
    val cast: List<String> = emptyList(),
    val director: String? = null
)

@Serializable
data class Season(
    val id: String,
    val seriesId: String,
    val sourceId: String,
    val seasonNumber: Int,
    val name: String? = null,
    val overview: String? = null,
    val posterUrl: String? = null,
    val episodeCount: Int? = null,
    val year: Int? = null
)

@Serializable
data class Episode(
    val id: String,
    val seriesId: String,
    val seasonNumber: Int,
    val episodeNumber: Int,
    val sourceId: String,
    val name: String? = null,
    val overview: String? = null,
    val stillUrl: String? = null,
    val runtimeMinutes: Int? = null,
    val airDate: String? = null
)

@Serializable
data class SeriesDetails(
    val item: MediaItem,
    val seasons: List<Season> = emptyList(),
    val totalSeasons: Int? = null,
    val totalEpisodes: Int? = null,
    val status: String? = null,
    val cast: List<String> = emptyList()
)

enum class StreamType {
    HLS,
    MP4,
    DASH,
    OTHER
}

@Serializable
data class SubtitleTrack(
    val label: String,
    val url: String,
    val language: String? = null,
    val mimeType: String? = null
)

@Serializable
data class StreamSource(
    val sourceId: String,
    val sourceName: String,
    val url: String,
    val type: StreamType = StreamType.HLS,
    val quality: String? = null,
    val headers: Map<String, String> = emptyMap(),
    val subtitles: List<SubtitleTrack> = emptyList(),
    val referer: String? = null
)
