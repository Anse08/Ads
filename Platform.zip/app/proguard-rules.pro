# Add project specific ProGuard rules here.
# Keep Kotlin serialization
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.AnnotationsKt
-keepclassmembers class kotlinx.serialization.json.** {
    *** Companion;
}
-keepclasseswithmembers class kotlinx.serialization.json.** {
    kotlinx.serialization.KSerializer serializer(...);
}
-keep,includedescriptorclasses class com.example.moviestvapp.**$$serializer { *; }
-keepclassmembers class com.example.moviestvapp.** {
    *** Companion;
}
-keepclasseswithmembers class com.example.moviestvapp.** {
    kotlinx.serialization.KSerializer serializer(...);
}
