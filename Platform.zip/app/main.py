from fastapi import FastAPI, Query, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pathlib import Path
from typing import Optional
import random

BASE_DIR = Path(__file__).resolve().parent.parent

app = FastAPI(title="E-commerce Ad Spy & Product Research Platform")

app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))

DUMMY_PRODUCTS = [
    {
        "id": 1,
        "product_title": "Portable Mini Blender USB Rechargeable",
        "image_url": "https://images.unsplash.com/photo-1570222094114-d054a817e56b?w=400&q=80",
        "country": "Algeria",
        "active_ad_count": 42,
        "estimated_daily_sales": 180,
    },
    {
        "id": 2,
        "product_title": "Orthopedic Memory Foam Pillow",
        "image_url": "https://images.unsplash.com/photo-1584100936595-c0654b55a2e2?w=400&q=80",
        "country": "Morocco",
        "active_ad_count": 67,
        "estimated_daily_sales": 240,
    },
    {
        "id": 3,
        "product_title": "Smart Watch Fitness Tracker Pro",
        "image_url": "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400&q=80",
        "country": "Saudi Arabia",
        "active_ad_count": 128,
        "estimated_daily_sales": 520,
    },
    {
        "id": 4,
        "product_title": "LED Ring Light with Tripod Stand",
        "image_url": "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=400&q=80",
        "country": "France",
        "active_ad_count": 54,
        "estimated_daily_sales": 310,
    },
    {
        "id": 5,
        "product_title": "Electric Hair Straightener Brush",
        "image_url": "https://images.unsplash.com/photo-1522338140262-f46f5913618a?w=400&q=80",
        "country": "Algeria",
        "active_ad_count": 89,
        "estimated_daily_sales": 410,
    },
    {
        "id": 6,
        "product_title": "Car Vacuum Cleaner High Power",
        "image_url": "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400&q=80",
        "country": "Morocco",
        "active_ad_count": 33,
        "estimated_daily_sales": 150,
    },
    {
        "id": 7,
        "product_title": "Wireless Earbuds Noise Cancelling",
        "image_url": "https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=400&q=80",
        "country": "Saudi Arabia",
        "active_ad_count": 203,
        "estimated_daily_sales": 780,
    },
    {
        "id": 8,
        "product_title": "Posture Corrector Back Support Belt",
        "image_url": "https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=400&q=80",
        "country": "France",
        "active_ad_count": 76,
        "estimated_daily_sales": 290,
    },
]


@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


@app.get("/api/search")
async def search_products(
    keyword: Optional[str] = Query(default=None, description="Search keyword"),
    country: Optional[str] = Query(default=None, description="Country filter"),
):
    results = DUMMY_PRODUCTS.copy()

    if country and country.lower() != "all":
        results = [p for p in results if p["country"].lower() == country.lower()]

    if keyword:
        kw = keyword.lower().strip()
        results = [p for p in results if kw in p["product_title"].lower()]

    # Add slight variation to simulate live data
    for item in results:
        jitter = random.randint(-5, 5)
        item["active_ad_count"] = max(0, item["active_ad_count"] + jitter)
        item["estimated_daily_sales"] = max(0, item["estimated_daily_sales"] + jitter * 2)

    return {
        "query": {"keyword": keyword, "country": country},
        "count": len(results),
        "results": results,
    }
